import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Jayadev H | Technical Customer Success Engineer",
  description:
    "Technical Customer Success Engineer with 6+ years in enterprise SaaS onboarding, implementation, API troubleshooting and GenAI platform enablement.",
};

// Applies the saved or system theme before first paint to avoid a flash.
const themeScript = `try{var t=localStorage.getItem('theme');if(t==='dark'||(!t&&window.matchMedia('(prefers-color-scheme: dark)').matches)){document.documentElement.classList.add('dark')}}catch(e){}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body>{children}</body>
    </html>
  );
}

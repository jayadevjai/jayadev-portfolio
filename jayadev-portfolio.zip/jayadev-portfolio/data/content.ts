// All portfolio content lives here. Edit this file to customise the site.

export const profile = {
  name: "Jayadev H",
  title: "Technical Customer Success Engineer",
  positioning:
    "I help enterprise engineering teams adopt AI-powered SaaS platforms, from first discovery call to production support.",
  location: "Bengaluru, India",
  email: "jayadevjai1996@gmail.com",
  phone: "+91 7356752695",
  linkedin: "https://www.linkedin.com/in/jayadev-h",
  resume: "/Jayadev_H_Resume.pdf",
  openTo: [
    "Technical Customer Success",
    "Product Support",
    "SaaS Implementation",
    "Customer Success Engineering",
    "GenAI Platform Support",
  ],
  about: [
    "I have spent 6+ years between customers and technical products: onboarding enterprise teams, configuring workflows, troubleshooting APIs and integrations, and carrying customer feedback back to product and engineering.",
    "Most recently I supported engineering teams adopting AAVA, Ascendion's Generative AI and agentic platform. I took customer use cases from discovery and BRD validation through AI agent and workflow configuration, demos, UAT, deployment and production support.",
    "I like work where a vague customer requirement has to become something that runs reliably in production, and where the customer still understands how to use it afterwards.",
  ],
};

export const stats = [
  { value: "6+", label: "years in SaaS onboarding, implementation and support" },
  { value: "10+", label: "engineering teams onboarded onto AAVA" },
  { value: "15+", label: "demos, onboarding sessions and workshops delivered" },
  { value: "20%", label: "shorter customer onboarding ramp-up time" },
];

// The delivery lifecycle shown in the hero. Each stage reflects work described in the resume.
export const lifecycle = [
  {
    stage: "Discovery",
    detail:
      "Run kickoff and discovery sessions, assess use cases, and find the engineering workflows that are worth automating.",
  },
  {
    stage: "Requirements and BRD",
    detail:
      "Gather requirements and validate the Business Requirements Document so the customer and the delivery team agree on scope.",
  },
  {
    stage: "Configuration",
    detail:
      "Configure AI agents and automated workflows using platform capabilities and prompt engineering. Coordinate Jira and GitHub integrations with delivery and security teams.",
  },
  {
    stage: "Demo and UAT",
    detail:
      "Demonstrate the solution to the customer's engineers and support user acceptance testing before anything goes live.",
  },
  {
    stage: "Deployment",
    detail:
      "Coordinate deployment with delivery and security, and check production readiness.",
  },
  {
    stage: "Enablement and support",
    detail:
      "Train users, troubleshoot platform, workflow and integration issues through Jira, and pass customer feedback to product and engineering.",
  },
];

export const caseStudies = [
  {
    title: "Onboarding engineering teams onto a GenAI platform",
    context: "Ascendion · AAVA platform",
    problem:
      "Engineering teams at enterprise customers needed to adopt a new Generative AI and agentic platform and understand where it fitted into their daily workflows.",
    solution:
      "Structured onboarding with platform access, feature walkthroughs, technical training and reusable guidance, backed by demos and enablement workshops.",
    contribution:
      "Led onboarding and enablement, and delivered the demonstrations and workshops myself.",
    outcome:
      "Onboarded 10+ engineering teams, delivered 15+ demos, sessions and workshops, and reduced onboarding ramp-up time by 20%.",
    tech: ["AAVA", "Generative AI", "Agentic AI", "Jira", "GitHub"],
  },
  {
    title: "From customer use case to production AI workflow",
    context: "Ascendion · AAVA platform",
    problem:
      "Customers arrived with automation ideas for engineering and operational work, but without defined requirements or a path to production.",
    solution:
      "Managed each use case through one lifecycle: discovery, requirements, BRD validation, agent and workflow configuration, demo, UAT, deployment and production enablement.",
    contribution:
      "Owned the use case end to end, configured agents and workflows with prompt engineering, and coordinated Jira and GitHub integrations with delivery and security teams.",
    outcome:
      "Use cases moved through validation and production-readiness checks with product, engineering, delivery, security and pre-sales aligned throughout.",
    tech: ["AI agents", "Prompt engineering", "BRD", "UAT", "Jira", "GitHub"],
  },
  {
    title: "Enterprise SaaS onboarding at scale",
    context: "Tenant · Senior Client Onboarding Analyst",
    problem:
      "Enterprise customers needed to get live on the product quickly and keep using it.",
    solution:
      "Structured onboarding and implementation guidance, proactive engagement, and workflow improvements and automation to shorten the onboarding process.",
    contribution:
      "Led onboarding and implementation for 20+ customers, and tracked customer health, NPS and retention to spot accounts that needed attention.",
    outcome:
      "Reduced time-to-value by 25%, increased product adoption by 30%, and cut onboarding cycle time by 30%.",
    tech: ["SaaS implementation", "HubSpot", "Zendesk", "SQL", "NPS"],
  },
  {
    title: "Level 2 support and integration troubleshooting",
    context: "Tenant · Senior Client Onboarding Analyst",
    problem:
      "High-priority product, API and integration issues needed fast, accurate resolution without breaking SLAs.",
    solution:
      "Acted as a primary escalation point, diagnosed API and integration issues, and worked with product, engineering and support to fix root causes.",
    contribution:
      "Troubleshot with Postman, Jira, Zendesk, DBeaver and New Relic, and ran SQL-based data validation and integrity checks.",
    outcome:
      "Maintained 95% SLA compliance on Level 2 incidents and reduced integration issue resolution timelines by 20%.",
    tech: ["REST APIs", "Postman", "SQL", "DBeaver", "New Relic", "Jira"],
  },
];

export const experience = [
  {
    role: "Senior Associate, Customer Success Engineer",
    company: "Ascendion Engineering",
    period: "Nov 2025 – Aug 2026",
    location: "Bengaluru",
    points: [
      "Onboarded and enabled 10+ engineering teams on the AAVA Generative AI and agentic platform: access, feature enablement, training and adoption support.",
      "Ran discovery and use-case assessments, then managed use cases through BRD validation, AI agent and workflow configuration, demos, UAT, deployment and production enablement.",
      "Delivered 15+ technical demos, onboarding sessions and workshops, and reduced onboarding ramp-up time by 20% with reusable guidance.",
      "Provided ongoing product support for enterprise customers, handling platform, workflow, integration and usage issues through Jira.",
      "Built Jira dashboards to show pending issues, ticket status, support workload and resolution progress.",
      "Worked with product, engineering, delivery, security and pre-sales teams to resolve issues and relay customer feedback.",
    ],
  },
  {
    role: "Senior Client Onboarding Analyst",
    company: "Tenant",
    period: "Sep 2023 – Apr 2025",
    location: "Bangalore",
    points: [
      "Led onboarding and SaaS implementation for 20+ enterprise customers, reducing time-to-value by 25% and increasing product adoption by 30%.",
      "Maintained 95% SLA compliance across Level 2 support incidents and escalations.",
      "Reduced integration issue resolution timelines by 20% through API troubleshooting and cross-functional coordination.",
      "Monitored customer health, NPS and retention to support proactive engagement and reduce churn.",
      "Promoted from Alokin Software and recognised with an Outstanding Client Performance award in September 2023.",
    ],
  },
  {
    role: "Senior Data Validation Analyst",
    company: "Alokin Software",
    period: "Apr 2022 – Aug 2023",
    location: "Thiruvananthapuram",
    points: [
      "Improved data validation efficiency by 30% through SQL-driven workflow optimisation.",
      "Reduced data error rates by 15% with structured validation and quality assurance processes.",
      "Mentored 5 junior analysts and helped resolve data migration discrepancies.",
    ],
  },
  {
    role: "Live Chat Consultant",
    company: "Xtreme Online Solutions",
    period: "Feb 2020 – Apr 2022",
    location: "Thiruvananthapuram",
    points: [
      "Handled 50+ daily customer interactions at 95%+ customer satisfaction, with first response under 30 seconds.",
      "Managed tickets in Zendesk and Freshdesk and increased conversion rates by 10%.",
    ],
  },
  {
    role: "Data Validation Trainee",
    company: "Benefitalign",
    period: "Oct 2019 – Feb 2020",
    location: "Trivandrum",
    points: [
      "Reached 98% compliance in US healthcare data validation and improved accuracy by 30% across 10,000+ records.",
    ],
  },
];

export const skillGroups = [
  {
    group: "Customer success and delivery",
    items: ["Enterprise onboarding", "SaaS implementation", "Customer enablement", "Product adoption", "Stakeholder management", "Escalation management", "Technical account management"],
  },
  {
    group: "Implementation lifecycle",
    items: ["Use-case discovery", "Requirements gathering", "BRD", "POC", "UAT", "Workflow configuration", "Deployment coordination", "Product demonstrations"],
  },
  {
    group: "Product support",
    items: ["Technical troubleshooting", "Root cause analysis", "Incident management", "SLA management", "Ticket management", "Technical escalation"],
  },
  {
    group: "Technical",
    items: ["REST APIs", "API troubleshooting", "Postman", "SQL", "MySQL", "Jira", "GitHub", "DBeaver", "New Relic"],
  },
  {
    group: "AI and automation",
    items: ["Generative AI", "Agentic AI", "AI agents", "Agentic workflows", "Prompt engineering", "Workflow automation", "GenAI platform enablement"],
  },
  {
    group: "Tools, data and process",
    items: ["HubSpot", "Zendesk", "Freshdesk", "Power BI", "Microsoft Excel", "Jira dashboards", "Agile", "Scrum", "SDLC", "SAFe"],
  },
];

export const education = [
  {
    title: "B.Tech, Computer Science",
    place: "University College of Engineering, Karyavattom (University of Kerala)",
    period: "2015 – 2019",
  },
  {
    title: "AI-Driven Data Analytics, Artificial Intelligence and Data Science",
    place: "Entri Elevate",
    period: "Oct 2025 – Apr 2026",
  },
];

export const certifications = [
  { name: "SAFe 6 Practitioner", issuer: "Scaled Agile", date: "Feb 2024" },
  { name: "AI-Driven Data Analytics Certification", issuer: "Entri", date: "2026" },
  { name: "Data Analytics Certification", issuer: "", date: "" },
  { name: "Data Analytics Certified User", issuer: "", date: "" },
  { name: "ChatGPT Essentials", issuer: "", date: "" },
];

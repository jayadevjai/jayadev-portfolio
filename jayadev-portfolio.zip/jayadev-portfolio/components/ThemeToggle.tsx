"use client";
import { useEffect, useState } from "react";

export default function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => setDark(document.documentElement.classList.contains("dark")), []);

  const toggle = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    try { localStorage.setItem("theme", next ? "dark" : "light"); } catch {}
  };

  return (
    <button
      onClick={toggle}
      aria-label={dark ? "Switch to light theme" : "Switch to dark theme"}
      className="rounded-md border border-slate-300 px-3 py-1.5 text-sm transition-colors hover:border-signal hover:text-signal dark:border-slate-700 dark:hover:border-sky-400 dark:hover:text-sky-400"
    >
      {dark ? "Light" : "Dark"}
    </button>
  );
}

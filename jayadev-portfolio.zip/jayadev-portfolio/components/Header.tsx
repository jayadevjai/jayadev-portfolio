import ThemeToggle from "./ThemeToggle";
import { profile } from "@/data/content";

const links = [
  { href: "#work", label: "Work" },
  { href: "#experience", label: "Experience" },
  { href: "#skills", label: "Skills" },
  { href: "#education", label: "Education" },
  { href: "#contact", label: "Contact" },
];

export default function Header() {
  return (
    <header className="sticky top-0 z-20 border-b border-slate-200 bg-paper/90 backdrop-blur dark:border-slate-800 dark:bg-night/90">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-3">
        <a href="#top" className="font-semibold tracking-tight">{profile.name}</a>
        <nav className="flex items-center gap-5 text-sm">
          <ul className="hidden gap-5 sm:flex">
            {links.map((l) => (
              <li key={l.href}>
                <a href={l.href} className="text-slate-600 transition-colors hover:text-signal dark:text-slate-400 dark:hover:text-sky-400">{l.label}</a>
              </li>
            ))}
          </ul>
          <ThemeToggle />
        </nav>
      </div>
    </header>
  );
}

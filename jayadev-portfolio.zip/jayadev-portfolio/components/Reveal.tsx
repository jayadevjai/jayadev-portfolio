"use client";
import { useEffect, useRef, useState, type ReactNode } from "react";

// One quiet fade-in used only on the case studies, so scrolling stays calm.
export default function Reveal({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === "undefined") { setShown(true); return; }
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { setShown(true); io.disconnect(); }
    }, { threshold: 0.15 });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <div ref={ref} className={`transition-opacity duration-700 ${shown ? "opacity-100" : "opacity-0"}`}>
      {children}
    </div>
  );
}

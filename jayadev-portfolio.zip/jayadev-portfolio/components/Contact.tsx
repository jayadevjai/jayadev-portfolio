import { profile } from "@/data/content";
import Section from "./Section";

export default function Contact() {
  const item = "rounded-xl border border-slate-300 p-5 transition-colors hover:border-signal dark:border-slate-700 dark:hover:border-sky-400";
  return (
    <Section id="contact" title="Contact" intro="I am open to Technical Customer Success, Product Support and SaaS Implementation roles. Email is the quickest way to reach me.">
      <div className="grid gap-4 sm:grid-cols-3">
        <a href={`mailto:${profile.email}`} className={item}>
          <p className="text-sm text-slate-500 dark:text-slate-400">Email</p>
          <p className="mt-1 break-all font-medium">{profile.email}</p>
        </a>
        <a href={`tel:${profile.phone.replace(/\s/g, "")}`} className={item}>
          <p className="text-sm text-slate-500 dark:text-slate-400">Phone</p>
          <p className="mt-1 font-medium">{profile.phone}</p>
        </a>
        <a href={profile.linkedin} target="_blank" rel="noopener noreferrer" className={item}>
          <p className="text-sm text-slate-500 dark:text-slate-400">LinkedIn</p>
          <p className="mt-1 font-medium">linkedin.com/in/jayadev-h</p>
        </a>
      </div>
    </Section>
  );
}

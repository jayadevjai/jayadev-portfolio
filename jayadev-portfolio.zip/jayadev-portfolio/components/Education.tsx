import { education, certifications } from "@/data/content";
import Section from "./Section";

export default function Education() {
  return (
    <Section id="education" title="Education and certifications">
      <div className="grid gap-12 md:grid-cols-2">
        <div>
          <h3 className="font-medium">Education</h3>
          <ul className="mt-4 space-y-5">
            {education.map((e) => (
              <li key={e.title}>
                <p className="font-medium">{e.title}</p>
                <p className="text-slate-600 dark:text-slate-400">{e.place}</p>
                <p className="font-mono text-sm text-slate-500">{e.period}</p>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="font-medium">Certifications and awards</h3>
          <ul className="mt-4 space-y-3">
            {certifications.map((c) => (
              <li key={c.name}>
                <span className="font-medium">{c.name}</span>
                {(c.issuer || c.date) && (
                  <span className="text-slate-600 dark:text-slate-400"> · {[c.issuer, c.date].filter(Boolean).join(", ")}</span>
                )}
              </li>
            ))}
            <li>
              <span className="font-medium">Outstanding Client Performance Recognition</span>
              <span className="text-slate-600 dark:text-slate-400"> · Tenant, Sep 2023</span>
            </li>
          </ul>
        </div>
      </div>
    </Section>
  );
}

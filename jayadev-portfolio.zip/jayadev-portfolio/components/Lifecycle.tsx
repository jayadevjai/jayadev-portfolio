"use client";
import { useState } from "react";
import { lifecycle } from "@/data/content";

// The memorable element: the delivery lifecycle Jayadev owns, as an interactive tracker.
export default function Lifecycle() {
  const [active, setActive] = useState(0);
  const last = lifecycle.length - 1;

  return (
    <div className="rounded-xl border border-slate-300 bg-white p-5 dark:border-slate-700 dark:bg-panel">
      <p className="font-mono text-sm text-slate-500 dark:text-slate-400">Use case lifecycle: select a stage</p>
      <ol className="mt-4" role="tablist" aria-label="Delivery lifecycle stages">
        {lifecycle.map((s, i) => {
          const isActive = i === active;
          const done = i < active;
          return (
            <li key={s.stage} className="relative pl-9">
              {i < last && (
                <span aria-hidden className={`absolute left-[11px] top-6 h-full w-px transition-colors ${done ? "bg-live" : "bg-slate-300 dark:bg-slate-700"}`} />
              )}
              <span
                aria-hidden
                className={`absolute left-0 top-0.5 flex h-6 w-6 items-center justify-center rounded-full border text-xs font-medium transition-colors ${
                  isActive ? "border-signal bg-signal text-white" : done ? "border-live bg-live text-white" : "border-slate-300 bg-white text-slate-500 dark:border-slate-600 dark:bg-panel dark:text-slate-400"
                }`}
              >
                {done ? "✓" : i + 1}
              </span>
              <button
                role="tab"
                aria-selected={isActive}
                onClick={() => setActive(i)}
                className={`w-full pb-4 text-left font-medium transition-colors ${isActive ? "text-signal dark:text-sky-400" : "hover:text-signal dark:hover:text-sky-400"}`}
              >
                {s.stage}
              </button>
            </li>
          );
        })}
      </ol>
      <p role="tabpanel" className="mt-1 min-h-[5.5rem] rounded-lg bg-paper p-4 text-sm leading-relaxed text-slate-700 dark:bg-night dark:text-slate-300">
        {lifecycle[active].detail}
      </p>
    </div>
  );
}

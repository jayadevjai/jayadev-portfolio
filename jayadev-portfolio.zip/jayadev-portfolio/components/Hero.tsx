import { profile, stats } from "@/data/content";
import Lifecycle from "./Lifecycle";

export default function Hero() {
  return (
    <section id="top" className="mx-auto max-w-5xl px-6 pb-16 pt-16 sm:pt-24">
      <div className="grid items-start gap-12 lg:grid-cols-[1.15fr_1fr]">
        <div>
          <p className="text-slate-600 dark:text-slate-400">{profile.name}, {profile.location}</p>
          <h1 className="mt-4 text-4xl font-semibold leading-[1.1] tracking-tight sm:text-5xl">
            {profile.title}
          </h1>
          <p className="mt-6 max-w-lg text-lg leading-relaxed text-slate-700 dark:text-slate-300">
            {profile.positioning}
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#contact" className="rounded-md bg-signal px-5 py-2.5 font-medium text-white transition-colors hover:bg-blue-700">
              Get in touch
            </a>
            <a href={profile.resume} download className="rounded-md border border-slate-300 px-5 py-2.5 font-medium transition-colors hover:border-signal hover:text-signal dark:border-slate-700 dark:hover:border-sky-400 dark:hover:text-sky-400">
              Download résumé
            </a>
          </div>
          <dl className="mt-12 grid max-w-lg grid-cols-2 gap-x-6 gap-y-6">
            {stats.map((s) => (
              <div key={s.label}>
                <dt className="text-2xl font-semibold">{s.value}</dt>
                <dd className="text-sm text-slate-600 dark:text-slate-400">{s.label}</dd>
              </div>
            ))}
          </dl>
        </div>
        <Lifecycle />
      </div>
    </section>
  );
}

import { profile } from "@/data/content";
import Section from "./Section";

export default function About() {
  return (
    <Section id="about" title="About">
      <div className="grid gap-10 md:grid-cols-[1.4fr_1fr]">
        <div className="space-y-4 leading-relaxed text-slate-700 dark:text-slate-300">
          {profile.about.map((p) => <p key={p}>{p}</p>)}
        </div>
        <div>
          <h3 className="font-medium">Open to roles in</h3>
          <ul className="mt-3 space-y-2 text-slate-700 dark:text-slate-300">
            {profile.openTo.map((r) => (
              <li key={r} className="border-l-2 border-signal pl-3">{r}</li>
            ))}
          </ul>
        </div>
      </div>
    </Section>
  );
}

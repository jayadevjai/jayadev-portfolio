import { experience } from "@/data/content";
import Section from "./Section";

export default function Experience() {
  return (
    <Section id="experience" title="Experience">
      <ol className="border-l border-slate-300 dark:border-slate-700">
        {experience.map((e) => (
          <li key={e.company + e.period} className="relative pb-12 pl-8 last:pb-0">
            <span aria-hidden className="absolute -left-[5px] top-2 h-2.5 w-2.5 rounded-full bg-signal" />
            <div className="flex flex-wrap items-baseline justify-between gap-x-4">
              <h3 className="text-lg font-semibold">{e.role}</h3>
              <p className="font-mono text-sm text-slate-500 dark:text-slate-400">{e.period}</p>
            </div>
            <p className="text-slate-600 dark:text-slate-400">{e.company}, {e.location}</p>
            <ul className="mt-3 max-w-2xl list-disc space-y-2 pl-5 leading-relaxed text-slate-700 marker:text-slate-400 dark:text-slate-300">
              {e.points.map((p) => <li key={p}>{p}</li>)}
            </ul>
          </li>
        ))}
      </ol>
    </Section>
  );
}

import { caseStudies } from "@/data/content";
import Section from "./Section";
import Reveal from "./Reveal";

const rows = [
  ["Problem", "problem"],
  ["Approach", "solution"],
  ["My role", "contribution"],
  ["Outcome", "outcome"],
] as const;

export default function CaseStudies() {
  return (
    <Section id="work" title="Selected work" intro="Case studies drawn from my customer delivery and support roles.">
      <div className="space-y-10">
        {caseStudies.map((c) => (
          <Reveal key={c.title}>
            <article className="rounded-xl border border-slate-200 bg-white p-6 transition-colors hover:border-signal dark:border-slate-800 dark:bg-panel dark:hover:border-sky-500 sm:p-8">
              <p className="text-sm text-slate-500 dark:text-slate-400">{c.context}</p>
              <h3 className="mt-1 text-xl font-semibold tracking-tight">{c.title}</h3>
              <dl className="mt-6 grid gap-x-8 gap-y-4 sm:grid-cols-[7rem_1fr]">
                {rows.map(([label, key]) => (
                  <div key={key} className="contents">
                    <dt className="font-medium text-slate-500 dark:text-slate-400">{label}</dt>
                    <dd className={`leading-relaxed ${key === "outcome" ? "font-medium" : "text-slate-700 dark:text-slate-300"}`}>{c[key]}</dd>
                  </div>
                ))}
              </dl>
              <ul className="mt-6 flex flex-wrap gap-2">
                {c.tech.map((t) => (
                  <li key={t} className="rounded-md bg-paper px-2.5 py-1 font-mono text-xs text-slate-700 dark:bg-night dark:text-slate-300">{t}</li>
                ))}
              </ul>
            </article>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}

import type { ReactNode } from "react";

export default function Section({ id, title, intro, children }: { id: string; title: string; intro?: string; children: ReactNode }) {
  return (
    <section id={id} className="mx-auto max-w-5xl px-6 py-20">
      <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">{title}</h2>
      {intro && <p className="mt-3 max-w-xl text-slate-600 dark:text-slate-400">{intro}</p>}
      <div className="mt-10">{children}</div>
    </section>
  );
}

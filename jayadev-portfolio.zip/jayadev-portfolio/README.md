# Jayadev H: Portfolio

Suggested repository name: `jayadev-portfolio`

## Overview
A single-page portfolio for a Technical Customer Success Engineer. The hero centres on an interactive tracker of the use-case delivery lifecycle (discovery to production support), and the "Selected work" section presents case studies from real customer delivery and support roles rather than code projects. All content comes from the résumé and LinkedIn profile; no metrics were added.

## Tech stack
- Next.js 14 (App Router), React 18, TypeScript
- Tailwind CSS 3 with class-based dark mode (follows system theme, with a toggle)
- No API keys, environment variables or external font/network dependencies

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000. For a production check: `npm run build && npm start`.

## Customise
- **All text and numbers:** edit `data/content.ts` (profile, stats, lifecycle stages, case studies, experience, skills, education, certifications).
- **Résumé download:** replace `public/Jayadev_H_Resume.pdf` (keep the filename, or update `profile.resume`).
- **Colours:** edit the `signal`, `live`, `paper`, `ink`, `night` and `panel` values in `tailwind.config.ts`.
- **Sections:** compose or reorder them in `app/page.tsx`.

## Structure
```
app/         layout, page, global styles
components/  Header, Hero, Lifecycle, About, CaseStudies, Experience, Skills, Education, Contact, Section, Reveal, ThemeToggle
data/        content.ts (single source of content)
public/      résumé PDF
```

## Deploy
Push to GitHub and import the repo in Vercel; no configuration is needed.
